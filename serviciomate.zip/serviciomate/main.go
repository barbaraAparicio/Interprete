package main

import (
	"fmt"

	"github.com/barbaraAparicio/serviciomate/api"
)

func main() {
	//var router = api.Routermod{}
	fmt.Println("Entre al main")
	//iniciando base de datos y router
	api.Comenzar()
}

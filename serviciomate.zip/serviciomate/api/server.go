package api

import (
	"fmt"
	"log"
	"os"

	"github.com/barbaraAparicio/serviciomate/api/controller"
	"github.com/joho/godotenv"
)

func Comenzar() {
	var service = controller.ServerBdRou{}
	var err error
	err = godotenv.Load()
	if err != nil {
		log.Fatalf("Error obteniendo variables %v", err)
	} else {
		fmt.Println("Hemos obtenido valores env ")
	}
	//llamar funcion que hace la conexion a la base de datos
	fmt.Println("Aqui se inicializo la base de datos")
	DbDriver := os.Getenv("DB_DRIVER")
	DBURL := fmt.Sprintf("%s:@/%s", os.Getenv("DB_USER"), os.Getenv("DB_NAME"))
	service.Conexion(DbDriver, DBURL) //
	defer service.DB.Close()
	//llamar funcion que inicializa el router
	fmt.Println("Aqui se inicializo EL ROUTER")

	service.Iniciar(fmt.Sprintf(":%s", os.Getenv("PUERTO")))

}

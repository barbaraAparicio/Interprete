package model

import (
	"fmt"
	"github.com/jinzhu/gorm"
)

type Operadores struct {
	Id       int
	Operador string
}

func (opera *Operadores) Obteneroperador(db *gorm.DB) ([]Operadores, error) {
	var err error
	var operadores = []Operadores{}

	err = db.Debug().Model(&Operadores{}).Limit(100).Find(&operadores).Error
	if err != nil {
		fmt.Println(err.Error())
	}
	return operadores, err
}

func (opera *Operadores) EncontrarOperador(db *gorm.DB, op string) (int, error) {
	var err error
	var count int

	err = db.Model(&Operadores{}).Where("operador = ?", op).Count(&count).Error
	if err != nil {
		fmt.Println(err.Error())
	}
	return count, err
}

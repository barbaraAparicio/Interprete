package operaciones

import (
	"fmt"

	"github.com/barbaraAparicio/serviciomate/api/model"
	"github.com/jinzhu/gorm"
)

func ConvertirStrList(cadena string, db *gorm.DB) []string {
	fmt.Println("convertir string")
	var listaOperadores = model.Operadores{}
	//operadoresAux, _ := listaOperadores.Obteneroperador(db) //volver a mostrar el err
	//variables para la obtencion de operadores
	//var operadores []string
	//iOperadorAux := 0

	//var arreglo []string
	var coincidenciaOperador int
	//sumindex := 0
	runes := []rune(cadena)
	var caracter string
	var caracter2 string

	//Aqui se obtienen los operadores en un arreglo de strings
	/*for _, operador := range operadoresAux {
		operadores[iOperadorAux] = operador.Operador
		iOperadorAux = iOperadorAux + 1
	}*/
	var numOp string
	var expresionLista []string
	expresionIndice := 0

	//recorrer la cadena infija para separar cada numero y operador
	for index := 0; index < len(cadena); index++ {
		if index+1 < len(cadena) {
			//se obtiene un caracter mas adelante
			caracter2 = string(runes[index : index+1])
			caracter = string(runes[index+1 : index+2])

			fmt.Println(caracter)
			fmt.Println(caracter2)
			//-----
			coincidenciaOperador, _ = listaOperadores.EncontrarOperador(db, caracter)
			if coincidenciaOperador != 0 {
				numOp = numOp + caracter2
			} else {
				fmt.Printf("--->", numOp)
				expresionLista[expresionIndice] = numOp
				expresionIndice++
				expresionLista[expresionIndice] = caracter
				expresionIndice++
				numOp = ""
			}
			//-----
			//se guarda el caracter en el arreglo auxiliar
			//arreglo[sumindex] = caracter2
			//sumindex++
			//se busca el operador en la base de datos
			/*coincidenciaOperador, _ = listaOperadores.EncontrarOperador(db, caracter)
			if coincidenciaOperador != 0 {
				for _, x := range arreglo {
					numOp += x
				}
				expresionLista[expresionIndice] = numOp
				expresionIndice++
				arreglo = nil
				sumindex = 0
			}*/
		}

	}

	return expresionLista
}

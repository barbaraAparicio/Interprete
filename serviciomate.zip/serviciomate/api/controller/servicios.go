package controller

import (
	"fmt"
	"log"

	"github.com/gorilla/mux"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
	"net/http"
)

type ServerBdRou struct {
	DB  *gorm.DB
	Rtr *mux.Router
}

func (serverBR *ServerBdRou) Conexion(tipoBD string, cadConexion string) {
	var err error
	serverBR.DB, err = gorm.Open(tipoBD, cadConexion)
	if err != nil {
		fmt.Printf("No se pudo conectar a la base de datos, ") //
		log.Fatal("Este es el error:", err)
	} else {
		fmt.Printf("wohuuuuu nos conectamos a la base de datos, ") //, Dbdriver)
	}
}
func (serverBR *ServerBdRou) Iniciar(puerto string) {
	serverBR.Rtr = mux.NewRouter()
	//manejador de router o endpoints

	serverBR.Rtr.HandleFunc("/evaluate", serverBR.CalculoMatematicos).Methods("POST")

	log.Fatal(http.ListenAndServe(puerto, serverBR.Rtr))

	fmt.Println("Corriendo servicio...")
}

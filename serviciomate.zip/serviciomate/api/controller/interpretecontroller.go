package controller

import (
	"encoding/json"
	"fmt"
	"github.com/barbaraAparicio/serviciomate/api/operaciones"
	"net/http"
)

type InfijaExpresion struct {
	Expresion string `json:"exp"`
}

type ResponseExpresion struct {
	ExpresionInfix  string   `json:"infix"`
	ExpresionPosfix []string `json:"posfix"`
	Result          float64  `json:"result"`
}

type BadResponse struct {
	Message string `json:"message"`
}

func (service *ServerBdRou) CalculoMatematicos(w http.ResponseWriter, r *http.Request) {
	fmt.Println("entro al servicio")
	w.Header().Set("Content-type", "application/json")

	var expresioni InfijaExpresion
	var respuestaBuena ResponseExpresion
	//obtenemos el json del body
	err := json.NewDecoder(r.Body).Decode(&expresioni)
	fmt.Println(expresioni.Expresion)
	if err != nil {
		fmt.Println("error")
		w.WriteHeader(http.StatusInternalServerError)
	}
	respuestaBuena.ExpresionInfix = expresioni.Expresion
	respuestaBuena.ExpresionPosfix = operaciones.ConvertirStrList(expresioni.Expresion, service.DB)
	fmt.Println()
	err3 := json.NewEncoder(w).Encode(&respuestaBuena)
	if err3 != nil {
		fmt.Println("error")
		w.WriteHeader(http.StatusInternalServerError)
	}

}
